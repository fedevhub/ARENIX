const mongoose = require('mongoose')

const bookingSchema = new mongoose.Schema({
    id_booking: {
        type: String,
        required: true
    },

    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
    },

    lapangan: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Lapangan',
        required: true,
    },

    tanggal: {
        type: String,
        required: true
    },

    jam_mulai: {
        type: String,
        required: true
    },

    jam_selesai: {
        type: String,
        required: true
    },

    durasi_jam: {
        type: String, 
        required: true
    },

    total_biaya: {
        type: String,
        required: true
    },

    status: {
        type: String,
        required: true,
        enum: ['Menunggu', 'Diesetujui', 'Ditolak']
    }
})

module.exports = mongoose.model('Booking', bookingSchema)