const mongoose = require('mongoose')

const jenisSchema = new mongoose.Schema({
    id_jenis: {
        type: String,
        require: true
    },

    nama: {
        type: String,
        require: true
    }
})

module.exports = mongoose.model('Jenis', jenisSchema)