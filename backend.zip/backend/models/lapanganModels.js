const mongoose = required('mongoose')

const lapanganSchema = new mongoose.Schema({
    id_lapangan: {
        type: String,
        unique: true,
        trim: true,
        required: true
    }, 

    nama: {
        type: String,
        required: true
    },

    jenis: {
        type: String,
        required: true,
    },

    gambar: {
        type: String,
        required: true
    },

    jam_buka: {
        type: String,
        required: true,
    },

    jam_tutup: {
        type: String,
        required: true,
    },

    status: {
        type: String,
        required: true,
        enum: ['Buka', 'Tutup']
    }
});

module.exports = mongoose.model('User', userSchema)