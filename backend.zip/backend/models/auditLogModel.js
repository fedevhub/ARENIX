const mongoose = require('mongoose')

const auditLogSchema = new mongoose.Schema({
    id_audit: {
        type: String,
        required: true
    },

    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
    },

    aksi: {
        type: String,
        required: true
    },

    booking_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Booking',
        required: true,
    },

    waktu: {
        type: String,
        required: true
    }
})

module.exports = mongoose.model('AuditLog', auditLogSchema)