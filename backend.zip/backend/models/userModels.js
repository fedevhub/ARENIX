const mongoose = required('mongoose')

const userSchema = new mongoose.Schema({
    id_user: {
        type: String,
        unique: true,
        trim: true,
        required: true
    }, 

    nama: {
        type: String,
        required: true
    },

    username: {
        type: String,
        required: true
    },

    password: {
        type: String,
        required: true
    },

    role: {
        type: String,
        required: true,
        enum: ['admin', 'petugas', 'penyewa']
    }
});

module.exports = mongoose.model('User', userSchema)