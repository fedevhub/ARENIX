const mongoose = require('mongoose')

const tarifSchema = new mongoose.Schema({
    id_tarif: {
        type: String,
        required: true
    },

    lapangan_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Lapangan',
        required: true, 
    },

    tipe_hari: {
        type: String,
        required: true,
        enum: ['Weekday', 'Weekend']
    },
    
    pakai_lampu: {
        type: String,
        required: true
    }
})

module.exports = mongoose.model('Tarif', tarifSchema)